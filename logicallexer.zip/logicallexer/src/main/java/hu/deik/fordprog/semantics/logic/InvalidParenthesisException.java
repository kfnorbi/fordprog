package hu.deik.fordprog.semantics.logic;

public class InvalidParenthesisException extends Exception {

	public InvalidParenthesisException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidParenthesisException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidParenthesisException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidParenthesisException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidParenthesisException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
